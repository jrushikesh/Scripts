
# coding: utf-8

# In[1]:

from bs4 import BeautifulSoup as soup
import requests
import pandas as pd
import datetime as dt


# In[2]:

url = "https://www.productreview.com.au/p/breville-bes860-barista-express.html"
mainPage = requests.get(url)
page_soup = soup(mainPage.content, 'html.parser')
reviews = page_soup.find_all(class_ = "review")


# In[3]:

DF_heading = ["Model number", "Date of Purchase", "Rating", "Reviewed On", "Short Review", "Reviews"]
review_dataframe = pd.DataFrame(columns = DF_heading)
review_dataframe


# In[4]:

for review in reviews:
    content_div = review.find(class_ = "review-content")
    labels = content_div.find_all(class_ = "label label-default")
    modelNumber = labels[0].get_text().split(":")[1].strip()
    purchaseDate = labels[1].get_text().split(":")[1].strip()
    rating_div = content_div.find(class_ = "rating-md")
    review_rating = rating_div.find("span", attrs = {"itemprop": "reviewRating"})
    rating_value = review_rating.find("span", attrs = {"itemprop": "ratingValue"}).get_text()
    best_rating = review_rating.find("span", attrs = {"itemprop": "bestRating"}).get_text()
    rating = rating_value + " out of " + best_rating
    reviewed_on = dt.datetime.strptime(rating_div.find("meta", attrs = {"itemprop" : "datePublished"})["content"], "%Y-%m-%d")
    reviewed_on_formatted = dt.date.strftime(reviewed_on,"%b %d, %Y")
    short_review = content_div.find("h3", attrs = {"itemprop": "name"}).get_text()
    long_review = content_div.find(class_ = "review-overall").find("span").get_text()
    
    # Append the row to data frame
    review_dataframe = review_dataframe.append({
        "Model number" : modelNumber,
        "Date of Purchase" : purchaseDate,
        "Rating" : rating,
        "Reviewed On" : reviewed_on_formatted,
        "Short Review" : short_review,
        "Reviews" : long_review
    }, ignore_index = True)


# In[5]:

review_dataframe


# In[ ]:




# In[ ]:



