
# coding: utf-8

# # SentiWordNet

# In[1]:

#import nltk
#nltk.download()


# In[2]:

#import sentiwordnet and wordnet
from nltk.corpus import sentiwordnet as swn
from nltk.corpus import wordnet as wn


# In[3]:

#All synsets for the word
for sense in wn.synsets('sad'):
    print("\nSense: ", sense.name())
    print("Synonyms: " , [lemma.name() for lemma in sense.lemmas()])
    print("Gloss Definition: " + sense.definition())
    print("Example Sentemces: " + str(sense.examples()))  


# In[4]:

#All entries for the word 'sad' in the senti-wordnet
example_senti_syn = swn.senti_synsets("sad")
print("Printing sentiment synsets for all the synsets of the word 'sad'\n")
for senti_synset in example_senti_syn:
    print(senti_synset.synset.name() + "\t" + str(senti_synset.pos_score())  + "\t" +  str(senti_synset.neg_score())
         + "\t" + str(senti_synset.obj_score()))


# In[ ]:



