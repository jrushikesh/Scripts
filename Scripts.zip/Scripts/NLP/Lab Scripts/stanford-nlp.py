
# coding: utf-8

# In[1]:

# Download the Stanford NLP tools
# http://nlp.stanford.edu/software/stanford-ner-2015-04-20.zip
# http://nlp.stanford.edu/software/stanford-postagger-full-2015-04-20.zip
# http://nlp.stanford.edu/software/stanford-parser-full-2015-04-20.zip
# https://github.com/shekhargulati/day20-stanford-sentiment-analysis-demo/raw/master/src/main/resources/edu/stanford/nlp/models/lexparser/englishPCFG.ser.gz


# In[2]:

import os
from nltk.parse import stanford
os.environ['JAVAHOME'] = 'C:/Program Files/Java/jre1.8.0_151'
os.environ['CLASSPATH'] = "B:/Natural Language Processing/stanford/stanford-parser-full-2015-04-20/"


# In[3]:

# POS tagging:
from nltk.tag import StanfordPOSTagger

stanford_pos_dir = 'B:/Natural Language Processing/stanford/stanford-postagger-full-2015-04-20/'
eng_model_filename= stanford_pos_dir + 'models/english-left3words-distsim.tagger'
my_path_to_jar= stanford_pos_dir + 'stanford-postagger.jar'

st = StanfordPOSTagger(model_filename=eng_model_filename, path_to_jar=my_path_to_jar) 
st.tag('Ram Sharma is studying at Aegis University in India'.split())


# In[4]:

#NER Tagging:
from nltk.tag import StanfordNERTagger

stanford_ner_dir = 'B:/Natural Language Processing/stanford/stanford-ner-2015-04-20/'
eng_model_filename= stanford_ner_dir + 'classifiers/english.all.3class.distsim.crf.ser.gz'
my_path_to_jar= stanford_ner_dir + 'stanford-ner.jar'

st = StanfordNERTagger(model_filename=eng_model_filename, path_to_jar=my_path_to_jar) 
st.tag('my weight is 30'.split())


# In[5]:

#Constituency Parser:
from nltk.parse.stanford import StanfordParser
parser=StanfordParser(model_path="B:/Natural Language Processing/stanford/stanford-parser-full-2015-04-20/englishPCFG.ser.gz")
sentences = list(parser.raw_parse("I like cats and dogs"))
#print(sentences)
for line in sentences:
    for sentence in line:
        sentence.draw()


# In[6]:

#Dependency Parser
from nltk.parse.stanford import StanfordDependencyParser
dep_parser=StanfordDependencyParser(model_path="edu/stanford/nlp/models/lexparser/englishPCFG.ser.gz")

sent = "The coach cut two players from the team"

print("\nPrinting tree")
for parse in dep_parser.raw_parse(sent):
    print(parse.tree())
result = dep_parser.raw_parse(sent)

print("\nPrinting tuples")
dep = result.__next__() #for other than python3 user: result.next()
list(dep.triples())


# In[ ]:



