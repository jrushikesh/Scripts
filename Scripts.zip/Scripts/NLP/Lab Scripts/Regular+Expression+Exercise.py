
# coding: utf-8

# In[1]:

import re
import datetime


# In[2]:

def yield_valid_dates(dateStr):
    for match in re.finditer(r"\d{1,2}-\d{1,2}-\d{4}", dateStr):
        try:
            date = datetime.datetime.strptime(match.group(0), "%m-%d-%Y")
            yield match.group(0)
            # or you can yield match.group(0) if you just want to
            # yield the date as the string it was found like 05-04-1999
        except ValueError:
            # date couldn't be parsed by datetime... invalid date
            pass


# In[3]:

testStr = """05-04-1999 here is some filler text in between the two dates 4-5-2016 then finally an invalid
 date 32-2-2016 here is also another invalid date, there is no 32d day of the month 6-32-2016. You can also not
 include the leading zeros like 4-2-2016 and it will still be detected"""

for date in yield_valid_dates(testStr):
    print(date)


# In[4]:

for match in re.finditer(r"\d{1,2}-\d{1,2}-\d{4}", testStr):
    print(match.group(0))


# In[ ]:




# In[ ]:




# In[5]:

import re
import datetime


# In[6]:

# Return True if the date is in the correct format
def checkDateFormat(myString):
    isDate = re.match('[0-1][0-9]\/[0-3][0-9]\/[1-2][0-9]{3}', myString)
    return isDate


# In[7]:

# Return True if the date is real date, by real date it means,
# The date can not be 00/00/(greater than today)
# The date has to be re# Return True if the date is real date, by real date it means,
# The date can not be 00/00/(greater than today)
# The date has to be real (13/32) is not acceptable
def checkValidDate(myString):
    # Get today's date
    today = datetime.date.today()
    myMaxYear = int(today.strftime('%Y'))

    if (myString[:2] == '00' or myString[3:5] == '00'):
        return False

    # Check if the month is between 1-12
    if (int(myString[:2]) >= 1 and int(myString[:2]) <=12):
        # Check if the day is between 1-31
        if (int(myString[3:5]) >= 1 and int(myString[3:5]) <= 31):
            # Check if the year is between 1900 to current year
            if (int(myString[-4:]) <= myMaxYear):
                return True
            else:
                return False
        else:
            return False
    else:
        return False


# In[8]:

testString = input('Enter your date of birth in MM/DD/yyyy format: ')

# Making sure the values are correct
print('Month:', testString[:2])
print('Date:', testString[3:5])
print('Year:', testString[-4:])

if (checkDateFormat(testString)):
    print('Passed the format test')
    if (checkValidDate(testString)):
        print('Passed the value test too.')
    else:
        print('But you failed the value test.')
else:
    print("Failed. Try again")


# In[ ]:




# In[ ]:




# In[9]:

import datetime
import re

def valid_date(datestring):
    try:
        mat=re.match('(\d{2})[/.-](\d{2})[/.-](\d{4})$', datestring)
        if mat is not None:
            print(mat.groups())
            datetime.datetime(*(map(int, mat.groups()[-1::-1])))
            return True
    except ValueError:
        pass
    return False


# In[10]:

valid_date('11/31/1992')


# In[11]:

valid_date('31/12/1992')


# In[ ]:




# In[ ]:




# #### Assignment question

# In[12]:

import re
import datetime


# In[13]:

exampleString = "15 November 1989"
date = re.match(r'([0]*[1-9]|[1][0-9]|[2][0-9]|[3][0-1]) (January|February|March|April|May|June|July|August|September|October|November|December) (\d+)',exampleString)
print(date)


# In[14]:

exampleString = "October 2013"
date = re.match(r'(January|February|March|April|May|June|July|August|September|October|November|December) (\d{4})',exampleString)
print(date)


# In[15]:

date = '31/12/1992'
pattern = re.compile(r'([0]*[1-9]|[1][0-9]|[2][0-9]|[3][0-1])[/]([0]*[1-9]|[1][0-2])[/](\d{4})')
print(re.match(pattern, date))


# In[16]:

date = '31.12.1992'
pattern = re.compile(r'([0]*[1-9]|[1][0-9]|[2][0-9]|[3][0-1])[.]([0]*[1-9]|[1][0-2])[.](\d{4})')
print(re.match(pattern, date))


# In[17]:

date = '31-12-1992'
pattern = re.compile(r'([0]*[1-9]|[1][0-9]|[2][0-9]|[3][0-1])[-]([0]*[1-9]|[1][0-2])[-](\d{4})')
print(re.match(pattern, date))


# In[18]:

date = '31-12-1992'
pattern = re.compile(r'([0]*[1-9]|[1][0-9]|[2][0-9]|[3][0-1])[/.-]([0]*[1-9]|[1][0-2])[/.-](\d{4})')
print(re.match(pattern, date))


# In[19]:

date = '1992-12-15'
pattern = re.compile(r'(\d{4})[/.-]([0]*[1-9]|[1][0-2])[/.-]([0]*[1-9]|[1][0-9]|[2][0-9]|[3][0-1])')
print(re.match(pattern, date))


# In[20]:

# Return True if the date is in the correct format
def checkDateFormat(myDate):
    if(re.match(r'([0]*[1-9]|[1-2][0-9]|[3][0-1]) (January|February|March|April|May|June|July|August|September|October|November|December) (\d+)', myDate)):
        print("Valid Format: ", myDate)
    elif(re.match(r'(January|February|March|April|May|June|July|August|September|October|November|December) (\d{4})', myDate)):
        print("Valid Format: ", myDate)
    elif(re.match(r'([0]*[1-9]|[1-2][0-9]|[3][0-1])[/.-]([0]*[1-9]|[1][0-2])[/.-](\d{4})', myDate)):
        print("Valid Format: ", myDate)
    elif(re.match(r'(\d{4})[/.-]([0]*[1-9]|[1][0-2])[/.-]([0]*[1-9]|[1-2][0-9]|[3][0-1])', myDate)):
        print("Valid Format: ", myDate)
    else:
        print("Invalid Format: ", myDate)


# In[21]:

checkDateFormat("15 November 1989")
checkDateFormat("October 2013")
checkDateFormat("16/11/2016")
checkDateFormat("16.11.2016")
checkDateFormat("16-11-2016")
checkDateFormat("2016-11-1") #Need to enter correct format
checkDateFormat("9.9.1994")
checkDateFormat("6.02.2006")
checkDateFormat("02-29-2011")
checkDateFormat("32-12-2011")
checkDateFormat("01@11@2011")
checkDateFormat("Cricket 2013")


# In[22]:

#for extracting time
time = '23-50'
pattern=re.compile(r'([0-1]*[0-9]|[2][0-3])[:-]([0-5][0-9])')
print(re.match(pattern, time))


# In[23]:

date = '31-12-1992'
pattern = re.compile(r'([0]*[1-9]|[1-2][0-9]|[3][0-1])[/.-]([0]*[1-9]|[1][0-2])[/.-](\d{4})')
print(re.match(pattern, date))


# In[24]:

#for extracting time 
pattern=re.compile(r'([0-1]*[0-9]:[0-5][0-9]|[2][0-3]:[0-5][0-9])') #will not match 04.00
print(re.match(pattern,"23:60")) #will not match 04.00


# In[25]:

def checkTimeFormat(myTime):
    if(re.match(r'([0-1]*[0-9]|[2][0-3])[:-]([0-5][0-9])', myTime)):
        print("Valid Time Format: ", myTime)
    else:
        print("Invald Time Format: ", myTime)


# In[26]:

checkTimeFormat("04:30")
checkTimeFormat("8:30")
checkTimeFormat("00:59")
checkTimeFormat("12:00")
checkTimeFormat("06:06")
checkTimeFormat("30:12")
checkTimeFormat("1:70")


# In[ ]:



