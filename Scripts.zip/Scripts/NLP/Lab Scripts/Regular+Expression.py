
# coding: utf-8

# ### A regular expression is a special sequence of characters that helps you match or find other strings or sets of strings, using a specialized syntax held in a pattern
# #### https://docs.python.org/3/howto/regex.html

# In[1]:

import re
#+ * ? $ ^ () {} [] \ |
#Identifiers \d \D \w \W \s \S . \b
#modifiers {}, + * ? ^ $ | [] {}
#white space characters \n \s \t \b \f \r


# In[2]:

#match : returns a match object on success, None on failure.
words=re.match(r'\w+',"Ram is 10 years old and Shyam is 5 years old.") 
print(words)


# In[3]:

#match : returns a match object on success, None on failure.
words=re.match(r'\w+',"@#%^&") 
print(words)


# In[4]:

matchObj = re.match( r'(.*) and (.*)', "Ram is 10 years old and Shyam is 5 years old.")

if matchObj:
    print("Match at index %s, %s" % (matchObj.start(), matchObj.end()))
    print("matchObj.group() : ", matchObj.group())
    print("matchObj.group(1): ", matchObj.group(1))
    print("matchObj.group(2): ", matchObj.group(2))
else:
    print("No match!!")


# In[5]:

matchObj = re.match( r'(.*) and (.*) and (.*)', "Ram is 10 years old and Shyam is 5 years old and Rushi is 24 years old.")

if matchObj:
    print("Match at index %s, %s" % (matchObj.start(), matchObj.end()))
    print("matchObj.group() : ", matchObj.group())
    print("matchObj.group(1): ", matchObj.group(1))
    print("matchObj.group(2): ", matchObj.group(2))
    print("matchObj.group(3): ", matchObj.group(3))
else:
    print("No match!!")


# In[6]:

#match ⇒ find something at the beginning of the string and return a match object.
#search ⇒ find something anywhere in the string and return a match object.


# In[7]:

#match ⇒ find something at the beginning of the string and return a match object.
matchObj = re.match( r'(S.*) and (.*)', "Ram is 10 years old and Shyam is 5 years old and Seeta is 2 yesrs old.")

if matchObj:
    print("Match at index %s, %s" % (match.start(), match.end()))
    print("matchObj.group() : ", matchObj.group())
    print("matchObj.group(1): ", matchObj.group(1))
    print("matchObj.group(2): ", matchObj.group(2))
else:
    print("No match!!")


# In[8]:

#search ⇒ find something anywhere in the string and return a match object.
matchObj = re.search( r'(S.*) and (.*)', "Ram is 10 years old and Shyam is 5 years old and Seeta is 2 years old.")

if matchObj:
    print("matchObj.group() : ", matchObj.group())
    print("matchObj.group(1): ", matchObj.group(1))
    print("matchObj.group(2): ", matchObj.group(2))
else:
    print("No match!!")


# In[9]:

#using findall function
exampleString = "Ram is 10 years old and Shyam is 5 years old and Seeta is 2 years old."
words=re.findall(r'\w+',exampleString) 
print(words)


# In[10]:

#using findall function
exampleString = "Ram is 10 years old and Shyam is 5 years old and Seeta is 2 years old."
words=re.findall(r'\w*',exampleString) 
print(words)


# In[11]:

#using findall function
words=re.findall(r'[A-Z]\w+',exampleString)  #words with first capital letter
print(words)


# In[12]:

#using findall function
digits=re.findall(r'\d+',exampleString) #\d+ same as [0-9]+
print(digits)


# In[13]:

#using findall function
digits=re.findall(r'\d{2}',exampleString) 
print(digits)


# In[14]:

#using findall function
ages = re.findall(r'(\d{0,2}) (years)', exampleString)
print(ages)


# In[15]:

#using findall function
exampleString = "Ram is 10 years old on January 2013 and Shyam is 5 years old on May 2011 and Seeta is 2 years old on June 2014."
date = re.findall(r'([A-Z][a-z]+) (\d+)',exampleString)
print(date)


# In[16]:

#using findall function
matches = re.findall( r'([A-Z]\w+) (\d+)', exampleString)

for match in matches:
    print(match)


# In[17]:

#using finditer function
print(exampleString)
matches = re.finditer( r'([A-Z]\w+) (\d+)', exampleString)

for match in matches:
    print("Match at index: %s, %s" % (match.start(), match.end()))
    print(match.group())


# In[18]:

#using compile
pattern = re.compile( r'([A-Z]\w+) (\d{4})')
for match in pattern.findall(exampleString):
    print(match)


# In[19]:

#Finding and replacing strings
print(exampleString)
print(re.sub(r'([A-Z]\w+) (\d+)',r"\2 of \1",exampleString)) #swap


# In[20]:

#Finding and replacing strings using compile
print(exampleString)
print(re.sub(r'\s',r'\t',exampleString)) #replace


# In[21]:

text = 'Rushikesh , ? ! Jadhav'
print(text)
print(re.sub(r'[,?! ]','',text)) #replace


# In[22]:

print(exampleString)
print(re.split('and',exampleString))


# In[23]:

print(re.split('(\s)',exampleString))


# In[24]:

#for extracting time 
pattern=re.compile(r'([0-1]*[0-9]:[0-5][0-9]|[2][0-3]:[0-5][0-9])') #will not match 04.00
print(re.findall(pattern,"Now its 24:00 pm")) #will not match 04.00


# In[25]:

date = '22'
pattern = re.compile(r'[0]*[1-9]|[1][0-9]|[2][0-9]|[3][0-1]')
print(re.findall(pattern, date))


# In[ ]:



