
# coding: utf-8

# ### Lexical knowledge network:  WordNet (http://www.nltk.org/howto/wordnet.html )#####

# In[1]:

#import nltk
#nltk.download('wordnet')


# In[2]:

from nltk.corpus import wordnet as wn


# In[3]:

print("Finding all senses from wordnet: " )
for sense in list(wn.all_synsets('n'))[:10]:
    print(sense)


# In[4]:

print("Print all sense from wordnet")
for p in ["n", "v", "a", "r"]:
    print(p, ": ", len(list(wn.all_synsets(p))))


# In[5]:

print("Finding all possible senses for a given word: " )
synsets = wn.synsets('bat')
print(synsets)


# In[6]:

print("Finding the semantic information about the senses: " )
for sense in synsets:
    print("\nSense: ", sense.name())
    print("Synonyms: " , [lemma.name() for lemma in sense.lemmas()])
    print("Gloss Definition: " + sense.definition())
    print("Example Sentemces: " + str(sense.examples()))   


# In[7]:

print("Finding all possible senses of words for a given parts-of-speech:" )
synsets = wn.synsets('bat','v')
print(synsets)


# In[8]:

print("Finding the sense information for a given parts-of-speech and sense number")
synset = wn.synset('bat.v.02')
print("Gloss definition: ", synset.definition())


# In[9]:

print("Find the semantic relations")
print("Hypernym (parent) sense: ", wn.synset('bat.n.01').hypernyms())
print("Hyponym(child) sense: ",wn.synset('bat.n.01').hyponyms())


# In[10]:

print("Find the common Hypernym or parent: ")
print(wn.synset('bat.n.02').lowest_common_hypernyms(wn.synset('cricket.n.02')))


# In[11]:

print("Find the lexical relations")

print("Sense: ", wn.synset('big.a.01'))
print("Lemma: ", [l.name() for l in wn.synset('big.a.01').lemmas()])
print ("Anotonyms: ", [a.name()for a in wn.synset('big.a.01').lemmas()[1].antonyms()])


# In[12]:

print("Find the lexical relations")

print("Sense: ", wn.synset('big.a.01'))
print("Lemma: ", [l.name() for l in wn.synset('big.a.01').lemmas()])
print ("Anotonyms: ")
for l in wn.synset('big.a.01').lemmas():
    for a in l.antonyms():
        print(l.name(), a.name())


# In[13]:

#Finding similarities between words
cricket = wn.synset('cricket.n.01')
bat = wn.synset('bat.n.02')


# In[14]:

#Path similarity:Return a score denoting how similar two word senses are, based on the shortest path that connects the senses in the is-a (hypernym/hypnoym) taxonomy. The score is in the range 0 to 1
print(cricket.path_similarity(bat))


# In[15]:

#Leacock-Chodorow Similarity: Return a score denoting how similar two word senses are, based on the shortest path that connects the senses (as above) and the maximum depth of the taxonomy in which the senses occur
print(cricket.lch_similarity(bat))


# In[16]:

# Wu-Palmer Similarity: Return a score denoting how similar two word senses are, based on the depth of the two senses in the taxonomy and that of their Least Common Subsumer (most specific ancestor node).
print(cricket.wup_similarity(bat))


# In[17]:

#jcn Similarity:
from nltk.corpus import wordnet_ic
brown_ic = wordnet_ic.ic('ic-brown.dat')
print(bat.jcn_similarity(cricket, brown_ic))


# In[ ]:



