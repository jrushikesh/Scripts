
# coding: utf-8

# In[1]:

#import nltk
#nltk.download('punkt')
#nltk.download('genesis')
#nltk.download('brown')
#nltk.download('universal_tagset')


# In[2]:

#An n-gram is a contiguous sequence of n items from a given sequence of text or speech. 
#The items can be syllables, letters, words or base pairs according to the application. 
import nltk
from nltk import word_tokenize
from nltk.util import ngrams

text = "I need to write a program in NLTK that breaks a corpus (a large collection of txt files) into unigrams, bigrams, trigrams, fourgrams and fivegrams. I need to write a program in NLTK that breaks a corpus"
token = nltk.word_tokenize(text)
bigrams = ngrams(token,2)
for grams in bigrams:print(grams)


# In[3]:

trigrams = ngrams(token,3)
for grams in trigrams:print(grams)


# In[4]:

from nltk.collocations import *
temp=nltk.collocations.BigramCollocationFinder.from_words(token)
for bigram, freq in temp.ngram_fd.items():
     print(bigram, freq)


# In[5]:

from nltk.collocations import *
tokens = nltk.wordpunct_tokenize(text)
temp=nltk.collocations.QuadgramCollocationFinder.from_words(token)
for fourgram, freq in temp.ngram_fd.items():  
    print(fourgram, freq)


# In[6]:

#Let us use Bigram Association measures which scores collocations or other associations
#(nlp.stanford.edu/fsnlp/promo/colloc.pdf)
#Example: pmi, likelihood_ratio, student_t,chi_sq,

bigram_measures = nltk.collocations.BigramAssocMeasures()
#Collect the bigram statistics from the corpus
finder = BigramCollocationFinder.from_words(nltk.corpus.genesis.words('english-web.txt'))
#find the top 10 bigrams from the corpus
finder.nbest(bigram_measures.pmi, 10) 


# In[7]:

#find collocations among tagged words using pmi:
finder = BigramCollocationFinder.from_words(nltk.corpus.brown.tagged_words('ca01', tagset='upenn_tagset'))
finder.nbest(bigram_measures.pmi, 5)


# In[8]:

from nltk.corpus import brown
test_sent = brown.sents(categories='news')[10]
print(test_sent)


# In[9]:

test_sent = brown.tagged_sents(categories='news')[10]
print(test_sent)


# In[10]:

#find collocations among tagged words using student_t measure :
finder = BigramCollocationFinder.from_words(nltk.corpus.brown.tagged_words('ca01', tagset='universal'))
finder.nbest(bigram_measures.student_t, 5)


# In[11]:

#find collocations among tagged words using likelihood_ratio measure :
finder = BigramCollocationFinder.from_words(nltk.corpus.brown.tagged_words('ca01', tagset='universal'))
finder.nbest(bigram_measures.likelihood_ratio, 5)


# In[12]:

#find collocations of tags:
finder = BigramCollocationFinder.from_words(t for w, t in nltk.corpus.brown.tagged_words('ca01', tagset='universal'))
finder.nbest(bigram_measures.pmi, 10)


# In[ ]:



