
# coding: utf-8

# In[1]:

from nltk.corpus import wordnet as wn


# In[2]:

for ss in wn.synsets('bank'):
    print(ss, ss.definition())


# In[3]:

from nltk.wsd import lesk


# In[4]:

sent = "I went to the bank to deposits my money".split()


# In[5]:

lesk(sent, 'bank', 'n')


# In[6]:

lesk(sent, 'bank', 'n').definition()


# In[7]:

#pip install pywsd
from pywsd.lesk import simple_lesk


# In[8]:

bank_sents = ['I went to the bank to deposit my money',
'The river bank was full of dead fishes']


# In[9]:

print("======== TESTING simple_lesk ===========\n")
from pywsd.lesk import simple_lesk
print("#TESTING simple_lesk() ...")
print("Context:", bank_sents[0])
answer = simple_lesk(bank_sents[0],'bank')
print("Sense:", answer)
print("Definition:",answer.definition())


# In[10]:

print("#TESTING simple_lesk() with POS ...")
print("Context:", bank_sents[1])
answer = simple_lesk(bank_sents[1],'bank','n')
print("Sense:", answer)
print("Definition:",answer.definition())


# In[11]:

plant_sents = ['The workers at the industrial plant were overworked',
'The plant was no longer bearing flowers']


# In[12]:

print("#TESTING simple_lesk() with POS ...")
print("Context:", plant_sents[0])
answer = simple_lesk(plant_sents[0],'plant','n', True)
print("Sense:", answer)
print("Definition:",answer.definition())


# In[13]:

print( "======== TESTING baseline ===========\n")
from pywsd.baseline import random_sense, first_sense
from pywsd.baseline import max_lemma_count as most_frequent_sense


# In[14]:

print( "#TESTING random_sense() ...")
print( "Context:", bank_sents[0])
answer = random_sense('bank')
print( "Sense:", answer)
print( "Definition:",answer.definition())


# In[15]:

print( "#TESTING first_sense() ...")
print( "Context:", bank_sents[0])
answer = first_sense('bank')
print( "Sense:", answer)
print( "Definition:",answer.definition())


# In[16]:

print( "#TESTING most_frequent_sense() ...")
print( "Context:", bank_sents[0])
answer = most_frequent_sense('bank')
print( "Sense:", answer)
print( "Definition:",answer.definition())


# In[17]:

from pywsd import disambiguate
disambiguate('I went to the bank to deposit my money')


# In[18]:

from pywsd.similarity import max_similarity
max_similarity('I went to the bank to deposit my money', 'bank', 'res', pos='n').definition()


# In[19]:

max_similarity('I went to the bank to deposit my money', 'bank', 'jcn', pos='n').definition()


# In[20]:

max_similarity('I went to the bank to deposit my money', 'bank', 'lin', pos='n').definition()


# In[21]:

max_similarity('I went to the bank to deposit my money', 'bank', 'lch', pos='n').definition()


# In[ ]:



