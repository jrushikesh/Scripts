
# coding: utf-8

# In[1]:

from gensim.models.keyedvectors import KeyedVectors
from gensim.models import word2vec
from nltk.corpus import brown 
from gensim import utils
from gensim.models.doc2vec import TaggedDocument
from gensim.models.doc2vec import TaggedLineDocument
from gensim import corpora, models, similarities


# In[2]:

#Training model (parameters size=100, window=5, min_count=5, workers=4)
model = word2vec.Word2Vec(brown.sents(), size=200)

#loading model
#word_vectors = KeyedVectors.load_word2vec_format('/tmp/vectors.txt', binary=False)  # C text format
#word_vectors = KeyedVectors.load_word2vec_format('/tmp/vectors.bin', binary=True)  # C binary format


# In[3]:

model.most_similar("eat")


# In[4]:

model.doesnt_match("breakfast cereal dinner lunch".split())


# In[5]:

model.similarity('woman', 'man')


# In[6]:

model.most_similar_cosmul(positive=['woman', 'king'], negative=['man'])


# In[ ]:



