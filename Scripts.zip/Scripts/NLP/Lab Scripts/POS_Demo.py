
# coding: utf-8

# ### In this tutorial, we will look at some of the off-the-shelf POS taggers and a minimalistic introduction to train them

# In[1]:

import nltk
nltk.download('tagsets')
nltk.download('averaged_perceptron_tagger')
nltk.download('treebank')
from nltk.help import upenn_tagset, claws5_tagset, brown_tagset


# #### Different tagsets exist. Choose depending on the end application required. Some tagsets have coarse tags while other have very fine tags

# In[2]:

print("Printing upenn_tagset")
print(upenn_tagset())


# In[3]:

print("Printing brown_tagset")
print(brown_tagset())


# In[4]:

print("Printing claws5_tagset")
print(claws5_tagset() )


# In[5]:

#DefaultTagger is a dumb tagger just assigns a default tag to every word
from nltk.tag.sequential import DefaultTagger
print("Default tagger")
default_tagger = DefaultTagger('None')
sent = "I love to play cricket"
print(default_tagger.tag(sent.split()))


# In[6]:

#Averaged Perceptron tagger
import nltk
words=nltk.word_tokenize("He is playing cricket on a playground")
tagged = nltk.pos_tag(words)
print(tagged)


# In[7]:

#Extracting training and test strings from Brown Corpus, a well known repository of 1 million words
from nltk.corpus import brown
brown_train = list(brown.tagged_sents(categories='news')[:500])
brown_test = list(brown.tagged_sents(categories='news')[500:600])


# In[8]:

#UnigramTagger assigns the most frequent tag of a word to all it's occurrences
from nltk.tag import UnigramTagger
print("Unigram tagger")

#Collect statistics from Brown corpus
unigram_tagger = UnigramTagger(brown_train)
#Evaluating unigram tagger on a set of test sentences 
print(unigram_tagger.evaluate(brown_test))
sent = "I love to play cricket"
print(unigram_tagger.tag(sent.split()))


# In[9]:

sent = "Sachin score is 100 runs in test match"
print(unigram_tagger.tag(sent.split()))
sent = "run running runs ran"
print(unigram_tagger.tag(sent.split()))


# In[10]:

#Extracting Brown Corpus, a well known repository of 1 million words
from nltk.corpus import brown
test_sent = brown.sents(categories='news')[0]
print(test_sent)
test_sent = brown.tagged_sents(categories='news')[0]
print(test_sent)


# ##### RegexpTagger is a rule based Tagger, We provide rules in the form of regular expressions

# In[11]:

# RegexpTagger
from nltk.corpus import brown
from nltk.tag.sequential import RegexpTagger
test_sent = brown.sents(categories='news')[0]
regexp_tagger = RegexpTagger(
        [(r'^-?[0-9]+(.[0-9]+)?$', 'CD'),   # cardinal numbers
                (r'(The|the|A|a|An|an)$', 'AT'),   # articles
                (r'.*able$', 'JJ'),                # adjectives
                (r'.*ness$', 'NN'),                # nouns formed from adjectives
                (r'.*ly$', 'RB'),                  # adverbs
                (r'.*s$', 'NNS'),                  # plural nouns
                (r'.*ing$', 'VBG'),                # gerunds
                (r'.*ed$', 'VBD'),                 # past tense verbs
                (r'(from|on|to|into|of)$', 'PREP'),   # prepositions
                (r'.*', 'NN')                      # nouns (default)
        ])
sent = "Sachin plays a game of Cricket. He scored 100 runs."
print(regexp_tagger.tag(sent.split()))
print(regexp_tagger.tag(test_sent))


# #### Let us try to train a HMM POS trainer on the brown corpus

# In[12]:

# Import the corpus
from nltk.corpus import treebank

# Train data - pretagged
train_data = treebank.tagged_sents()[:3000]

print(train_data[0])

# Import HMM module
from nltk.tag import hmm

# Setup a trainer with default(None) values
# And train with the data
trainer = hmm.HiddenMarkovModelTrainer()
tagger = trainer.train_supervised(train_data)

print(tagger)
# Prints the basic data about the tagger

print(tagger.tag("Today is a good day .".split()))

print(tagger.tag("Joe met Joanne in Delhi .".split()))

print(tagger.tag("Chicago is the birthplace of Ginny".split()))


# In[ ]:



