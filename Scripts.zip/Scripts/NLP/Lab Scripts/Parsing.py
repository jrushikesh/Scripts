
# coding: utf-8

# In[1]:

# Parser Demo
######################## Rule Based parsers####################
from nltk import CFG


# In[2]:

grammar =  CFG.fromstring("""
	S -> NP VP
	PP -> P NP
	NP -> AT N | N PP | AT N PP | DT N
	VP -> V NP | V PP | V NP PP
	AT -> 'a' | 'an' 
	DT -> 'the'
	N -> 'man'
	N -> 'boy'
	N -> 'restaurant'
	V -> 'saw'
	P -> 'in'
	""")
print(grammar)


# In[3]:

# Recursive Descent Parser
from nltk.parse import RecursiveDescentParser
sentence1 = "the man saw a boy"
sentence2 = "the man saw a boy in the restaurant"
parser = RecursiveDescentParser(grammar)


# In[4]:

parsed_trees = parser.parse(sentence2.split())
print("trees for: "+sentence2)
for tree in parsed_trees:
	print(tree)


# In[5]:

parsed_trees = parser.parse(sentence2.split())
print("tree for: "+sentence2)
for tree in parsed_trees:
	print(tree)


# In[6]:

#Shift Reduce Parser
from nltk.parse import ShiftReduceParser
sentence1 = "the man saw a boy"
sentence2 = "the man saw a boy in the restaurant"
parser = ShiftReduceParser(grammar)


# In[7]:

parsed_trees = parser.parse(sentence1.split())
print("trees for: "+sentence1)
for tree in parsed_trees:
	print(tree)


# In[8]:

parsed_trees = parser.parse(sentence2.split())
print("tree for : "+sentence2)
if parsed_trees:
	for tree in parsed_trees:
		print(tree)


# In[9]:

from nltk.parse import ChartParser
parser = ChartParser(grammar)


# In[10]:

parsed_trees = parser.parse(sentence2.split())
print("ChartParsing: tree for: "+sentence2)
if parsed_trees:
	for tree in parsed_trees:
		print(tree)


# In[ ]:



