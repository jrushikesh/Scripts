# -*- coding: utf-8 -*-
"""
Created on Wed Nov 15 06:47:59 2017

@author: Rushi
"""

#import sentiwordnet and wordnet
from nltk.corpus import sentiwordnet as swn
from nltk.corpus import wordnet as wn

#All synsets for the word
for sense in wn.synsets('sad'):
    print("\nSense: ", sense.name())
    print("Synonyms: " , [lemma.name() for lemma in sense.lemmas()])
    print("Gloss Definition: " + sense.definition())
    print("Example Sentemces: " + str(sense.examples()))

#All entries for the word 'sad' in the senti-wordnet
example_senti_syn = swn.senti_synsets("sad")
print("Printing sentiment synsets for all the synsets of the word 'sad'\n")
for senti_synset in example_senti_syn:
    print(senti_synset.synset.name() + "\t" + str(senti_synset.pos_score())  + "\t" +  str(senti_synset.neg_score())
         + "\t" + str(senti_synset.obj_score()))

######################################################################################################

import csv
from nltk.corpus import sentiwordnet as swn

################## Loading data file #######################
reader_train = csv.reader(open('B:/Natural Language Processing/Lab Scripts/data/sentiment_analysis/training.csv','r'))
reader_test = csv.reader(open('B:/Natural Language Processing/Lab Scripts/data/sentiment_analysis/test.csv','r'))
training_data = []
test_data = []
header = 1
for row in reader_train:
        if header==1:
                header=0
                continue
        training_data.append(row)
header=1
for row in reader_test:
        if header==1:
                header=0
                continue
        test_data.append(row)

# Examples from training data
print(training_data[1])
print(len(training_data), len(test_data))

#Required for Bag of words (unigram features) creation
vocabulary = [x.lower() for tagged_sent in training_data for x in tagged_sent[0].split()]
print(len(vocabulary))
vocabulary = list(set(vocabulary))
vocabulary.sort() #sorting the list
print(len(vocabulary))
# print(vocabulary)

from nltk.corpus import stopwords
vocabulary = [word for word in vocabulary if not word in set(stopwords.words('english'))]

# #### Extracting Features
# #### Prepare a unigram feature vector based on the presence or absence of words#########

def get_unigram_features(data,vocab):
    fet_vec_all = []
    for tup in data:
        single_feat_vec = []
        sent = tup[0].lower() #lowercasing the dataset
        for v in vocab:
            if sent.__contains__(v):
                single_feat_vec.append(1)
            else:
                single_feat_vec.append(0)
        fet_vec_all.append(single_feat_vec)
    return fet_vec_all

get_unigram_features("movie is fantastic", vocabulary)

# #### Add sentiment scores from sentiwordnet, here we take the average sentiment scores of all words

def get_senti_wordnet_features(data):
    fet_vec_all = []
    for tup in data:
        sent = tup[0].lower()
        words = sent.split()
        pos_score = 0
        neg_score = 0
        for w in words:
            senti_synsets = swn.senti_synsets(w.lower())
            for senti_synset in senti_synsets:
                p = senti_synset.pos_score()
                n = senti_synset.neg_score()
                pos_score+=p
                neg_score+=n
                break #take only the first synset (Most frequent sense)
        fet_vec_all.append([float(pos_score),float(neg_score)])
    return fet_vec_all

# #### Merge the two scores ####

def merge_features(featureList1,featureList2):
    # For merging two features
    if featureList1==[]:
        return featureList2
    merged = []
    for i in range(len(featureList1)):
        m = featureList1[i]+featureList2[i]
        merged.append(m)
    return merged

#extract the sentiment labels by making positive reviews as class 1 and negative reviews as class 2
def get_lables(data):
    labels = []
    for tup in data:
        if tup[1].lower()=="neg":
            labels.append(-1)
        else:
            labels.append(1)
    return labels

def calculate_precision(prediction, actual):
    prediction = list(prediction)
    correct_labels = [predictions[i]  for i in range(len(predictions)) if actual[i] == predictions[i]]
    precision = float(len(correct_labels))/float(len(prediction))
    return precision

def real_time_test(classifier,vocab):
    print("Enter a sentence: ")
    inp = input()
    print(inp)
    feat_vec_uni = get_unigram_features(inp,vocab)
    feat_vec_swn =get_senti_wordnet_features(test_data)
    feat_vec = merge_features(feat_vec_uni, feat_vec_swn)

    predict = classifier.predict(feat_vec)
    if predict[0]==1:
        print("The sentiment expressed is: positive")
    else:
        print("The sentiment expressed is: negative")

# #### Training and Evaluation
# #### Preparing training and test tuples
# #### The feature_vecor set looks like [featurevector1, featurevector2,...,featurevectorN] where each featurevectorX is a list
# #### The label set looks like [label1,label2,...,labelN]

training_unigram_features = get_unigram_features(training_data,vocabulary) # vocabulary extracted in the beginning
training_swn_features = get_senti_wordnet_features(training_data)

training_features = merge_features(training_unigram_features,training_swn_features)

training_labels = get_lables(training_data)

test_unigram_features = get_unigram_features(test_data,vocabulary)
test_swn_features=get_senti_wordnet_features(test_data)
test_features= merge_features(test_unigram_features,test_swn_features)

test_gold_labels = get_lables(test_data)

######################################################################################################

# Naive Bayes Classifier
from sklearn.naive_bayes import MultinomialNB
nb_classifier = MultinomialNB().fit(training_features,training_labels) #training process
predictions = nb_classifier.predict(test_features)
print("Precision of NB classifier is")
predictions = nb_classifier.predict(training_features)
precision = calculate_precision(predictions,training_labels)
print("Training data\t" + str(precision))
predictions = nb_classifier.predict(test_features)
precision = calculate_precision(predictions,test_gold_labels)
print("Test data\t" + str(precision))
#Real time tesing
real_time_test(nb_classifier,vocabulary)

######################################################################################################

# SVM Classifier
#Refer to : http://scikit-learn.org/stable/modules/svm.html
from sklearn.svm import LinearSVC
svm_classifier = LinearSVC(penalty='l2', C=0.01).fit(training_features,training_labels)
predictions = svm_classifier.predict(training_features)
print("Precision of linear SVM classifier is:")
precision = calculate_precision(predictions,training_labels)
print("Training data\t" + str(precision))
predictions = svm_classifier.predict(test_features)
precision = calculate_precision(predictions,test_gold_labels)
print("Test data\t" + str(precision))
#Real time tesing
real_time_test(svm_classifier,vocabulary)

######################################################################################################

#
from nltk.sentiment.vader import SentimentIntensityAnalyzer
sid = SentimentIntensityAnalyzer()
print(sid.polarity_scores('Movie is good'))

######################################################################################################

#Logistic regression classifier
from sklearn.linear_model import LogisticRegression
LogisticRegression_classifier = LogisticRegression(penalty='l2', C=0.01).fit(training_features,training_labels)
predictions = LogisticRegression_classifier.predict(training_features)
print("Precision of Logistic Regression classifier is:")
precision = calculate_precision(predictions,training_labels)
print("Training data\t" + str(precision))
predictions = LogisticRegression_classifier.predict(test_features)
precision = calculate_precision(predictions,test_gold_labels)
print("Test data\t" + str(precision))
#Real time tesing
real_time_test(LogisticRegression_classifier,vocabulary)

######################################################################################################

#Decision Tree Classifier
from sklearn.tree import DecisionTreeClassifier
DecisionTree_classifier = DecisionTreeClassifier(criterion = 'entropy', random_state = 0).fit(training_features,training_labels)
predictions = DecisionTree_classifier.predict(training_features)
print("Precision of Logistic Regression classifier is:")
precision = calculate_precision(predictions,training_labels)
print("Training data\t" + str(precision))
predictions = DecisionTree_classifier.predict(test_features)
precision = calculate_precision(predictions,test_gold_labels)
print("Test data\t" + str(precision))
#Real time tesing
real_time_test(DecisionTree_classifier,vocabulary)

######################################################################################################

import pandas as pd
DF_heading = ["Dataset", "Naive Bayes", "SVM", "Decision Tree", "Logistic Regression"]
classifier_dataframe = pd.DataFrame(columns = DF_heading)
classifier_dataframe
######################################################################################################
